A Pen created at CodePen.io. You can find this one at https://codepen.io/daniandl/pen/OgbXzK.

 Reference: https://dribbble.com/shots/3144676-Checkbox-Animation